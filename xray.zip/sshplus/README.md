# SSHPLUS MANAGER — XRAY EDITION (atualizado 2026)

Instalador `Plus` atualizado com o módulo **Xray-core** integrado ao menu de ferramentas do SSHPLUS MANAGER.

## Arquivos

| Arquivo | O que é |
|---|---|
| **`Plus`** | Instalador principal (autossuficiente — o Xray já vai embutido dentro dele) |
| `xray` | Módulo Xray separado (referência / instalação manual em `/bin/xray`) |
| `patch_menu.sh` | Patch que insere a opção **31** no menu (idempotente, com backup/rollback) |
| `originais/` | Arquivos originais do repositório para comparação |

## Como instalar no VPS (Ubuntu 18.04+ / Debian 9+)

**Opção A — hospede o `Plus` (GitHub seu, Gist, ou qualquer URL raw) e rode:**

```bash
apt-get update -y && apt-get upgrade -y
wget https://SEU-LINK/raw/Plus -O Plus
chmod +x Plus && ./Plus
```

**Opção B — sem hospedar (copia direto):**

```bash
# do seu PC:
scp Plus root@IP-DO-VPS:/root/
# no VPS:
chmod +x Plus && ./Plus
```

## O que mudou em relação ao script original

1. **Atualizações modernas:**
   - Adicionado `apt-get upgrade -y` (com `--force-confdef/--force-confold`, sem travar em prompt)
   - Pacotes corrigidos: `python-pip` → `python3-pip`, removido o pacote inexistente `netstat`, adicionados `socat`, `cron`, `uuid-runtime`
   - `pip` → `pip3` para o speedtest-cli
2. **Xray nas ferramentas:** opção **[31] XRAY** dentro do menu (`menu` → `[19] MAIS` → `[31] XRAY`), com indicador ◉/○ de instalado.
3. **Watchdog systemd** (`sshplus-xray-watch.path`): se você usar a opção `28 — ATUALIZAR SCRIPT` (que baixa o menu original do repositório de novo), o watchdog detecta a mudança no `/bin/menu` e **reaplica a opção 31 automaticamente**.

## O módulo Xray (`/bin/xray`)

```
[01] INSTALAR / REINSTALAR XRAY
      ├─ VLESS + WebSocket (sem TLS — porta padrão 8080, path /sshplus)
      └─ VLESS + TCP + REALITY (camuflagem — porta padrão 443, SNI destino configurável)
[02] CRIAR USUARIO XRAY      (gera UUID + mostra link vless:// pronto)
[03] REMOVER USUARIO
[04] USUARIOS + LINKS
[05] ALTERAR PORTA
[06] REINICIAR SERVICO
[07] STATUS / LOGS
[08] DESINSTALAR XRAY
```

- Instala via script oficial [XTLS/Xray-install](https://github.com/XTLS/Xray-install) com fallback manual (zip do release no GitHub)
- Libera a porta no `ufw` automaticamente
- Binário: `/usr/local/bin/xray` • Config: `/usr/local/etc/xray/config.json` • Serviço: `systemctl status xray`
- Usuários persistem no `config.json` (editado via `jq`)

## Observações

- O módulo fica guardado em `/usr/local/lib/sshplus-xray/` (sobrevive a reinstalações do painel).
- A opção `29 — REMOVER SCRIPT` do painel original **não** remove o Xray. Para removê-lo: `menu` → `19` → `31` → opção `08`, e depois:
  ```bash
  rm -rf /usr/local/lib/sshplus-xray
  systemctl disable sshplus-xray-watch.path 2>/dev/null
  rm -f /etc/systemd/system/sshplus-xray-watch.{path,service}
  ```
- Créditos do painel base mantidos (CRAZY VPN / @crazy_vpn) — é a base dele, apenas com o Xray integrado.
