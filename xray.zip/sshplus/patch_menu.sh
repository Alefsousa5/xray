#!/bin/bash
#====================================================
# PATCH MENU - INTEGRA O XRAY AO MENU SSHPLUS (OP 31)
# IDEMPOTENTE: pode rodar quantas vezes quiser
#====================================================
[[ ! -e /bin/menu ]] && exit 0
[[ ! -e /bin/xray && -e /usr/local/lib/sshplus-xray/xray ]] && {
  cp -f /usr/local/lib/sshplus-xray/xray /bin/xray && chmod +x /bin/xray
}
grep -q "SSHPLUS-XRAY-PATCH" /bin/menu && exit 0
cp -f /bin/menu /bin/menu.bak-xray 2>/dev/null
python3 - <<'PY_SSHPLUS_XRAY'
import sys, subprocess, shutil
p = '/bin/menu'
try:
    with open(p, encoding='utf-8') as f:
        lines = f.read().split('\n')
except Exception:
    sys.exit(1)
if any('SSHPLUS-XRAY-PATCH' in l for l in lines):
    sys.exit(0)
out = []
ok_var = False
ok_dsp = False
ok_cas = False
for line in lines:
    if line.strip() == '0|00)':
        out.append('   31|xray|XRAY) #SSHPLUS-XRAY-PATCH')
        out.append('   clear')
        out.append('   [[ -e /bin/xray ]] && xray || { echo -e "\\033[1;31mMODULO XRAY NAO ENCONTRADO!\\033[0m"; sleep 2; }')
        out.append('   menu2')
        out.append('   ;;')
        out.append(line)
        ok_cas = True
        continue
    out.append(line)
    if line.startswith('autm=$(grep "menu;"'):
        out.append('[[ -e /usr/local/etc/xray/config.json ]] && stsx=$(echo -e "\\033[1;32m◉ ") || stsx=$(echo -e "\\033[1;31m○ ") #SSHPLUS-XRAY-PATCH')
        ok_var = True
    if 'BOT TELEGRAM' in line and line.rstrip().endswith('"'):
        out.append('echo -e "\\033[1;31m[\\033[1;36m31\\033[1;31m] \\033[1;37m• \\033[1;33mXRAY (VLESS/REALITY) $stsx\\033[1;31m" #SSHPLUS-XRAY-PATCH')
        ok_dsp = True
if not (ok_var and ok_dsp and ok_cas):
    sys.exit(1)
with open(p, 'w', encoding='utf-8') as f:
    f.write('\n'.join(out))
if subprocess.call(['bash', '-n', p]) != 0:
    shutil.copy(p + '.bak-xray', p)
    sys.exit(1)
PY_SSHPLUS_XRAY
rm -f /bin/menu.bak-xray
exit 0
